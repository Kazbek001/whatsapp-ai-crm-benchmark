# Как открыть и сдать Task 3

1. Для просмотра распакуй архив и открой `project/README.md` и `project/notebooks/01_data_analysis.ipynb`. Ноутбук уже содержит вывод ячеек, таблицы и графики.
2. Для защиты открой `Task_3_Defense_RU.md`. Сначала пройди четыре пробных вопроса, затем сам повтори практические действия из таблицы.
3. Для переноса на GitHub используй `task3.bundle`. В нём исходная история из репозитория, указанного в паспорте Task 2, отдельный коммит Task 3 и тег `task3-v1.0`. ZIP содержит и обычную копию файлов в `project/`.

Из папки с распакованным архивом в PowerShell:

```powershell
git clone --branch main ./task3.bundle whatsapp-ai-crm-benchmark
cd whatsapp-ai-crm-benchmark
git tag --list
git remote set-url origin https://github.com/YOUR_ACCOUNT/YOUR_REPO.git
git push -u origin main
git push origin task3-v1.0
```

Подставь URL своего репозитория. Для нового публичного репозитория создай его пустым. Если обновляешь действующий репозиторий и Git отклоняет push из-за новых коммитов, сначала проверь и объедини изменения. В LMS сдай публичную ссылку и `reports/Task_3_Report.md`. Открой опубликованный README на GitHub и проверь, что загружаются графики, ноутбук и C4-диаграмма.
